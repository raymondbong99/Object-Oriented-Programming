//Library
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

//Main class 
//Initialization and create new components
public class Recognition extends JFrame implements ActionListener
{	
	JFrame f = new JFrame();
	
	JLabel l1 = new JLabel("Simple Object Recognition System");
	JLabel l2 = new JLabel("Let's Try This Out");
	JLabel l3 = new JLabel();
	JLabel l4 = new JLabel();
	JLabel l5 = new JLabel();
	
	JButton b1 = new JButton("RUN");
	JButton b2 = new JButton("CLEAR");
	JButton b3 = new JButton("UPLOAD");
	
	ButtonGroup cbg = new ButtonGroup();
	JCheckBox r1 = new JCheckBox("RED", false);
	JCheckBox r2 = new JCheckBox("MAGENTA", false);
	JCheckBox r3 = new JCheckBox("CYAN", false);
	
	JPanel p1 = new JPanel(new FlowLayout());
	JPanel p2 = new JPanel(new GridLayout(3,0));
	JPanel p3 = new JPanel(new BorderLayout());
	JPanel p4 = new JPanel(new FlowLayout());
	JPanel p5 = new JPanel(new GridLayout(3,2,1,1));
	
	Font f1 = new Font("Comic Sans MS",Font.BOLD + Font.ITALIC,30);
	Font f2 = new Font("Arial Black",Font.BOLD,20);
	Font f3 = new Font("Arial",Font.BOLD + Font.ITALIC,20);
	
	int x,y,x2,y2 = 0;
	int px,py,pw,ph;
	Graphics2D g2;
	ArrayList<String> list = new ArrayList<String>();
	int index = list.indexOf("Camel");
	
	//Constructor.
	Recognition()
	{
		setSize(1300,700);
		setResizable(false);
		setTitle("OOP Assignment");
		setDefaultCloseOperation(f.EXIT_ON_CLOSE);
		
		
		l1.setFont(f1);
		l1.setForeground(Color.WHITE);
		l1.setBackground(Color.RED);
		l1.setHorizontalAlignment(JLabel.CENTER);
		p1.setBackground(Color.decode("#550000"));
		p1.add(l1);
		getContentPane().add(BorderLayout.NORTH, p1);
		
		
		r1.setForeground(Color.RED);
		r2.setForeground(Color.MAGENTA);
		r3.setForeground(Color.CYAN);
		cbg.add(r1);
		cbg.add(r2);
		cbg.add(r3);
		p2.add(r1);
		p2.add(r2);
		p2.add(r3);
		p2.setBackground(Color.decode("#FFCCBC"));
		p2.setPreferredSize(new Dimension(100,10));
		p2.setMaximumSize(new Dimension(100, 10));
		p2.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(5.0f)));
		getContentPane().add(BorderLayout.WEST, p2);
		
		l2.setFont(f2);
		l2.setForeground(Color.decode("#003333"));
		l2.setHorizontalAlignment(JLabel.CENTER);
		p3.add(l2);
		p3.setBackground(Color.decode("#D49A6A"));
		p3.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(5.0f)));
		getContentPane().add(BorderLayout.CENTER, p3);
		
		l4.setHorizontalAlignment(JLabel.CENTER);
		l4.setVerticalAlignment(JLabel.TOP);
		l5.setFont(f3);
		l5.setVerticalAlignment(JLabel.BOTTOM);
		l5.setHorizontalAlignment(JLabel.CENTER);
		l5.setForeground(Color.GREEN);
		
		p4.add(b1);
		p4.add(b2);
		p4.add(b3);
		p4.setBackground(Color.GRAY);
		getContentPane().add(BorderLayout.SOUTH, p4);
		
		p5.add(l5);
		p5.setBackground(Color.decode("#D49A6A"));
		p5.setPreferredSize(new Dimension(300,200));
		p5.setMaximumSize(new Dimension(300, 200));
		p5.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(5.0f)));
		getContentPane().add(BorderLayout.EAST, p5);
		
		r1.addActionListener(this);
		r2.addActionListener(this);
		r3.addActionListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		MyMouseListener ml = new MyMouseListener();
		addMouseListener(ml);
		addMouseMotionListener(ml);
		
		list.add("Camel");
		list.add("Squirrel");
		list.add("Leopard");
		list.add("Elk");
		list.add("Bear");
		list.add("Elephant");
		list.add("Polar Bear");
		list.add("Tiger");
		list.add("Lion");
		list.add("Hyena");
		list.add("Parrot");
		list.add("Ape");
		list.add("Fox");
		list.add("Snake");
		list.add("Wolf");
		list.add("Rabbit");
		list.add("HedgeHog");
		list.add("Cheetah");
	}	
	
	//Mouse pressed starting point.
	public void setStartPoint(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
		
	//Mouse release end point.	
	public void setEndPoint(int x, int y)
	{
		x2 = (x);
		y2 = (y);
	}

	//Rectangle drawing with x-axis , y-axis , width and height.
	public void drawCaptureRect(Graphics g, int x, int y, int x2, int y2)
	{		
		px = Math.min(x,x2);
		py = Math.min(y,y2);
		pw = Math.abs(x-x2);
		ph = Math.abs(y-y2);
		g.drawRect(px, py, pw, ph);
	}
	
	//Nested class for mouse action.
	public class MyMouseListener extends MouseAdapter 
	{
		public void mousePressed(MouseEvent me) 
		{
            setStartPoint(me.getX(), me.getY());
        }


        public void mouseDragged(MouseEvent me) 
		{
			setEndPoint(me.getX(), me.getY());
            repaint();
        }


        public void mouseReleased(MouseEvent me) 
		{
			setEndPoint(me.getX(), me.getY());
			capture();
			repaint();				
		}
	}
	
	//Upload image from GUI interface.	
	public void openImageFile()
	{
		BufferedImage bi = null;
		JFileChooser jfc= new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		jfc.setDialogTitle("Selet an image");
		jfc.setAcceptAllFileFilterUsed(false);
		FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG and JPG images", "png","jpg");
		jfc.addChoosableFileFilter(filter);
			
		int returnValue = jfc.showOpenDialog(null); //invoke the showsOpenDialog function to show save dialog
		if (returnValue == JFileChooser.APPROVE_OPTION)
		{
			File selectedFile = jfc.getSelectedFile();
			System.out.println("Selected file: " + selectedFile.getAbsolutePath());
			try
			{
				bi = ImageIO.read(selectedFile);
				bi.getScaledInstance(800, 533,Image.SCALE_SMOOTH);
				p3.add(l3);
				l2.setVisible(false);
				l3.setHorizontalAlignment(JLabel.CENTER); 
				l3.setIcon(new ImageIcon(bi)); 
				
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("Cancelled the operation");
		}
	}
	
	//Create sub-image 
	public void capture()
	{
		BufferedImage dest = null;
		try
		{
			ImageIcon icon = (ImageIcon)l3.getIcon();
			BufferedImage sub = (BufferedImage)((Image)icon.getImage());
			Robot rbt = new Robot();
			Rectangle rect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			sub = rbt.createScreenCapture(rect);
			dest = sub.getSubimage(px, py, pw, ph);
			dest.getScaledInstance(200,150,Image.SCALE_SMOOTH);
			l4.setIcon(new ImageIcon(dest)); 
			p5.add(l4);
			g2 = dest.createGraphics();
			g2.dispose();
			File f = new File("SubImage.jpg");
			ImageIO.write(dest,"jpg",f);
			f.deleteOnExit();
			System.out.println("Screenshot successful");
		}
		catch(AWTException | IOException | NullPointerException e)
		{
			System.out.println("Image not found!");
		}
					
	}
  
	//Clear current data
	public void removeRect() 
	{
		l4.setIcon(null);
		l4.revalidate();
		l5.setText("");
		l5.revalidate();
	}
	
	//Retrieve new object from array lists.
	private void update()
	{
		l5.setText("This is ( " +list.get(index)+ " )");
	}
	
	//Using Graphics2D 
	//Implement graphic outcome.
	public void paint(Graphics g) 
	{
		super.paint(g);
		g2 = (Graphics2D)g;
		int thickness = 2;
		g2.setStroke(new BasicStroke(thickness));
		if(r1.isSelected())
		{
			g.setColor(Color.RED);
		}
		else if(r2.isSelected())
		{
			g.setColor(Color.MAGENTA);
		}	
		else if(r3.isSelected())
		{
			g.setColor(Color.CYAN);	
		}
		drawCaptureRect(g, x, y, x2, y2);
		g2.dispose();
	}
	
	//Button action.
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == b3)
		{
			openImageFile();
		}
		else if(e.getSource() == b2)
		{
			removeRect();
		}
		else if(e.getSource() == b1)
		{
			BufferedImage check = null;
			try
			{
				check = ImageIO.read(new File("SubImage.jpg"));
				if(++index == list.size())
				{
					index = 0;
				}
				update();
			}
			catch(IOException ioe)
			{
				System.out.print("Error! No image exists.\n");
			}
		}
	}		
	
	//Main function.
	public static void main(String args[])
	{
		Recognition rec = new Recognition();
		rec.setVisible(true);
	}
}	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
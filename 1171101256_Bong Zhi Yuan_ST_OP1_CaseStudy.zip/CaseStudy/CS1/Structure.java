public class Structure extends Quiz
{	
	String answer;
	
	public void Question_1()
	{
		System.out.println("\nQ1. What is the language used in this OOP course?");
		do
		{
			answer = input.nextLine();
			if(answer.equalsIgnoreCase("Java"))
			{
				System.out.print("\nCorrect!");
				System.out.println("");
			}
			else 
			{
				System.out.print("Wrong! Please try again: ");
			}
		}while(!answer.equalsIgnoreCase("Java"));
	}	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void Question_2()
	{
		System.out.println("\nQ2. What is the command to print an output?");
		answer = input.nextLine();
		while(!answer.equals("System.out.print()"))
		{
			System.out.print("Wrong! Please try again: ");
			answer = input.nextLine();
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void Question_3()
	{
		System.out.println("\nQ3. How to compile Test.java using command prompt?");
		answer = input.nextLine();
		while(!answer.equals("javac Test.java"))
		{
			System.out.print("Wrong! Please try again: ");
			answer = input.nextLine();
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void Question_4()
	{
		System.out.println("\nQ4. How to run Test.java using command prompt?");
		answer = input.nextLine();
		while(!answer.equals("java Test"))
		{
			System.out.print("Wrong! Please try again: ");
			answer = input.nextLine();
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void Question_7()
	{
		System.out.println("\nQ7. What is the output of the following coding?");
		System.out.println("public class AddTwoNumbers {");
		System.out.println("	public static void main(String[] args) {");
		System.out.println("	int num1 = 5, num2 = 15, sum;");
		System.out.println("	sum = num1 + num2;");
		System.out.println("	System.out.println(+ sum );");
		System.out.println("	}");
		System.out.println("}");
		answer = input.nextLine();
		while(!answer.equals("20"))
		{
			System.out.print("Wrong! Please try again: ");
			answer = input.nextLine();
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
};	
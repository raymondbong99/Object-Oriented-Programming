public class Multiple extends Quiz
{
	char choice;
	
	public void Question_5()
	{
		System.out.println("\nQ5. Which of the package contains mathematical functions?");
		System.out.println("");
		System.out.println("A. import java.lang.* 		| B. import java.awt.*");
		System.out.println("C. import java.util.Scanner; 	| D. import java.util.ArrayList");
		choice = input.next().charAt(0);
		while(!(choice == 'A' || choice == 'a'))
		{
			System.out.print("Wrong! Please try again: ");
			choice = input.next().charAt(0);
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void Question_6()
	{
		System.out.println("\nQ6. Where does a java program start executing instructions from?");
		System.out.println("");
		System.out.println("A. class | B. source file | C. main method | D. object");
		choice = input.next().charAt(0);
		while(!(choice == 'C' || choice == 'c'))
		{
			System.out.print("Wrong! Please try again: ");
			choice = input.next().charAt(0);
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void Question_8()
	{	
		System.out.println("\nQ8. What is the output of the following coding?");
		System.out.println("");
		System.out.println("public class MyFirstJavaProgram {");
		System.out.println("	static void main(String []args) {");
		System.out.println("		System.out.println('Hello World');");
		System.out.println("	}");
 		System.out.println("}\n");
		System.out.println("A. Hello World | B. String | C. MyFirstJavProgram | D. compilation error");
		choice = input.next().charAt(0);
		while(!(choice == 'D' || choice == 'd'))
		{
			System.out.print("Wrong! Please try again: ");
			choice = input.next().charAt(0);
		}
		System.out.print("\nCorrect!");	
		System.out.println("");
	}
			
};	
	
	
	
	
	
	
		
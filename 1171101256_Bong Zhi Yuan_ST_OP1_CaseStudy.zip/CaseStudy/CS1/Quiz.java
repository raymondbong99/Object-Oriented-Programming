import java.util.*;

public class Quiz
{
	Scanner input = new Scanner(System.in);
	
	public void Tester()
	{
		String name;
		char option;
		
		System.out.println("\nWhat is your name? ");
		name = input.nextLine();
		while(!name.matches("[a-zA-Z , ]+"))
		{
			System.out.print("\nError, re-enter your name: ");
			name = input.nextLine();
		}
		System.out.println("\nHello tester, " + name + ".");
		System.out.print("\nReady for the quiz? (Y/N):");
		
		option = input.next().charAt(0);
		while(!(option == 'Y' || option == 'y' || option == 'N' || option =='n'))
		{
			System.out.print("\nInvalid input! Try again: ");
			option = input.next().charAt(0);
		}
		if(option == 'Y'|| option == 'y')
		{
			System.out.println("\nLet's start!!");
		}
		else if(option == 'N'|| option == 'n')
		{
			System.out.println("\nGood bye ~");
			System.exit(0);
		}	
	}
	
	public static void main(String[] args)
	{
		System.out.println("\nPrepared by : Bong Zhi Yuan (1171101256)");
		System.out.println("\nWelcome to the SIMPLE QUIZ SYSTEM!");
		System.out.println("");
		Quiz q = new Quiz();
		Structure s = new Structure(); 
		Multiple m = new Multiple();
		q.Tester();
		s.Question_1();
		s.Question_2();
		s.Question_3();
		s.Question_4();
		m.Question_5();
		m.Question_6();
		s.Question_7();
		m.Question_8();
		System.out.println("\nThank you for your participating!");
	}			
};

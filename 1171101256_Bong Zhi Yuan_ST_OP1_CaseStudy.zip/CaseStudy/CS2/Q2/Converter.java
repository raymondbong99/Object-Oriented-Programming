import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;

public class Converter extends JFrame implements ActionListener 
{
	JLabel label = new JLabel("Distance : ");
	JTextField input = new JTextField(10);
	JButton button = new JButton("Convert");
	JTextArea output = new JTextArea("",7,10);
	CheckboxGroup cbg = new CheckboxGroup();
	Checkbox cb1 = new Checkbox("Convert MILES to KM", cbg, true);
	Checkbox cb2 = new Checkbox("Convert KM to MILES", cbg, false);
	
	public Converter()
	{
		setLayout(new FlowLayout());
		setSize(220, 320);
		output.setColumns(15);
		output.setLineWrap(true);
		label.setFont(new Font("Serif", Font.BOLD, 15));
		button.setFont(new Font("Serif", Font.BOLD, 15));
		button.addActionListener(this);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(cb1);
		add(cb2);
		add(label);
		add(input);
		add(button);
		add(output);
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		double n, result;
		if(e.getSource() == button)
		{
			if(cb1.getState() == true)
			{	
				n = Double.parseDouble(input.getText());
				result = n / 0.62; 
				output.setText(input.getText() + " miles equals to " + (String.valueOf(result)) + " kilometres");
			}
			else if (cb2.getState() == true)
			{
				n = Double.parseDouble(input.getText());
				result = n * 0.62;				
				output.setText(input.getText() + " kilometres equals to " + (String.valueOf(result)) + " miles");
			}
		}
	}
	
	public static void main(String [] args)
	{
		Converter c = new Converter();
		c.setVisible(true);
	}
}








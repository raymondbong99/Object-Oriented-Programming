import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class Password extends Applet implements ActionListener
{	
	Label lb, lb2;
	TextField tf;
	Button b;
	Font f;
	
	public void init()
	{
		setLayout(new FlowLayout(FlowLayout.LEFT));
		f = new Font("Serif", Font.BOLD, 22);
		lb = new Label("Enter text: ");
		add(lb);
		tf = new TextField(15);
		add(tf);
		b = new Button("ENTER");
		add(b);	
		b.addActionListener(this);
		lb2 = new Label("");
		lb2.setFont(f);
		add(lb2);
		
	}
	

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == b)
		{
			if(tf.getText().equals("multimedia"))
			{
				lb2.setText("Access Accepted");
			}
			else
			{
				lb2.setText("Access Denied");
			}
		}
	}				
}	